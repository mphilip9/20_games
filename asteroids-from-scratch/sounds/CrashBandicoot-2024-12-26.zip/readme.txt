Crash Bandicoot 
20 games Challenge
Godot Engine

Project by DarkDes,
2024-12-26

Only 2 levels.

Resources:
Almost all the graphics and sounds are ripped from the Crash games.
The model of the Enemy Bee and the music is made by me.


Controls:
WASD, Arrows - move
Space - jump
F, Control - attack

Enter, Space - accept (in menu, gameover screen)